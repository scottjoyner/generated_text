The issue here is the missing metadata from the missing colums, the data quality issue wit hthe urls is real here.
